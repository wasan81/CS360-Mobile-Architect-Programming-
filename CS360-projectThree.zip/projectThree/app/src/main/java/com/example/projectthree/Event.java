package com.example.projectthree;

import java.io.Serializable;

public class Event implements Serializable {

    private int id;
    private String name;
    private String date;
    private String time;
    private String location;

    // Default constructor
    public Event() {
    }

    // Constructor with ID (useful for events fetched from the database)
    public Event(int id, String name, String date, String time, String location) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }


    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }


}
