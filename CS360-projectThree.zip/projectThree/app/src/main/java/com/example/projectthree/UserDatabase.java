package com.example.projectthree;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "events_db";
    private static final int DATABASE_VERSION = 1;

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create "events" table
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, date TEXT, time TEXT, location TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS events");
        onCreate(db);
    }

    // Add an event
    public long addEvent(String name, String date, String time, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);
        values.put("location", location);

        return db.insert("events", null, values);
    }
    // Add user to the database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        // Check if the username already exists
        try (Cursor cursor = db.query("users", new String[]{"username"}, "username = ?",
                new String[]{username}, null, null, null)) {
            if (cursor.getCount() > 0) {
                return false;
            }
        }


        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }


    // Get all events
    public List<Event> getAllEvents() {
        List<Event> eventList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query all events
        try (Cursor cursor = db.rawQuery("SELECT * FROM events", null)) {
            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") Event event = new Event(
                            cursor.getInt(cursor.getColumnIndex("id")),
                            cursor.getString(cursor.getColumnIndex("name")),
                            cursor.getString(cursor.getColumnIndex("date")),
                            cursor.getString(cursor.getColumnIndex("time")),
                            cursor.getString(cursor.getColumnIndex("location"))
                    );
                    eventList.add(event);
                } while (cursor.moveToNext());
            }
        }

        return eventList;
    }

    // Update an event
    public boolean updateEvent(long id, String name, String date, String time, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);
        values.put("location", location);

        return db.update("events", values, "id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    // Delete an event
    public boolean deleteEvent(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("events", "id = ?", new String[]{String.valueOf(id)}) > 0;
    }
    // Validate user credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});


        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }
}
