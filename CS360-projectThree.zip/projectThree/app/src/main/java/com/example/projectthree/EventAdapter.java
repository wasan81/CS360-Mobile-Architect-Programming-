package com.example.projectthree;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Event> eventList;
    private UserDatabase dbHelper;

    public EventAdapter(List<Event> eventList) {
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_event_item, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.nameTextView.setText(event.getName());
        holder.dateTextView.setText(event.getDate());
        holder.timeTextView.setText(event.getTime());
        holder.locationTextView.setText(event.getLocation());

        // Set delete button click listener
        holder.deleteButton.setOnClickListener(v -> {
            dbHelper = new UserDatabase(v.getContext());
            if (dbHelper.deleteEvent(event.getId())) {
                // Remove event from the list and notify the adapter
                eventList.remove(position);
                notifyItemRemoved(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }


    @SuppressLint("NotifyDataSetChanged")
    public void updateEventList(List<Event> newEventList) {
        eventList = newEventList;
        notifyDataSetChanged();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, dateTextView, timeTextView, locationTextView;
        Button deleteButton;

        public EventViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.event_name);
            dateTextView = itemView.findViewById(R.id.event_date);
            timeTextView = itemView.findViewById(R.id.event_time);
            locationTextView = itemView.findViewById(R.id.event_location);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
