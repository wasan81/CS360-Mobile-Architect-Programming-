package com.example.projectthree;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class add_delete_event extends AppCompatActivity {

    private UserDatabase dbHelper;
    private RecyclerView recyclerView;
    private EventAdapter eventAdapter;
    private EditText eventNameInput, eventDateInput, eventTimeInput, eventLocationInput;
    private Button addEventButton, backToEventDisplayButton;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_delete_event);

        Log.d("AddDeleteEvent", "Activity loaded successfully");


        dbHelper = new UserDatabase(this);

        // Initialize views
        eventNameInput = findViewById(R.id.event_name);
        eventDateInput = findViewById(R.id.event_date);
        eventTimeInput = findViewById(R.id.event_time);
        eventLocationInput = findViewById(R.id.event_location);
        addEventButton = findViewById(R.id.addEventButton);
        recyclerView = findViewById(R.id.recyclerView);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventAdapter = new EventAdapter(dbHelper.getAllEvents());
        recyclerView.setAdapter(eventAdapter);

        // Add event
        addEventButton.setOnClickListener(v -> {
            String name = eventNameInput.getText().toString().trim();
            String date = eventDateInput.getText().toString().trim();
            String time = eventTimeInput.getText().toString().trim();
            String location = eventLocationInput.getText().toString().trim();

            if (name.isEmpty() || date.isEmpty() || time.isEmpty() || location.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add the new event to the database
            long eventId = dbHelper.addEvent(name, date, time, location);
            if (eventId != -1) {
                // Refresh the RecyclerView to show the new event
                eventAdapter.updateEventList(dbHelper.getAllEvents());
                Toast.makeText(this, "Event added successfully!", Toast.LENGTH_SHORT).show();
                clearInputFields();
            } else {
                Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
            }
        });

        // Reference the back arrow ImageView
        ImageView backArrow = findViewById(R.id.backArrow);

        // Set click listener for back navigation
        backArrow.setOnClickListener(v -> {
            Intent intent = new Intent(add_delete_event.this, event_display.class);
            startActivity(intent);
            finish();
        });
    }
    private void clearInputFields() {
        eventNameInput.setText("");
        eventDateInput.setText("");
        eventTimeInput.setText("");
        eventLocationInput.setText("");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
