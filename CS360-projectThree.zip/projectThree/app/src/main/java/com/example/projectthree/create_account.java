package com.example.projectthree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class create_account extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private UserDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);


        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        Button createAccountButton = findViewById(R.id.create_account_button);


        dbHelper = new UserDatabase(this);


        createAccountButton.setOnClickListener(view -> {
            // Call createAccount method
            createAccount();
        });
    }

    private void createAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Input validation
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 8) {
            Toast.makeText(this, "Password must be at least 8 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to create a new account
        boolean isAdded = dbHelper.addUser(username, password);
        if (isAdded) {
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            // Redirect to login screen
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }
}
