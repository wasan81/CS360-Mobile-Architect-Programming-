package com.example.projectthree;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class event_display extends AppCompatActivity {

    private static final int ADD_EVENT_REQUEST_CODE = 1;  // Request code for adding new events
    private RecyclerView recyclerView;
    private EventAdapter eventAdapter;
    private UserDatabase dbHelper;
    private List<Event> eventList;  // List to hold events
    private TextView emptyTextView;  // TextView to show when no events are present

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_display);

        recyclerView = findViewById(R.id.recyclerView);
        emptyTextView = findViewById(R.id.emptyTextView);
        Button addEventButton = findViewById(R.id.addEventButton);
        Button signOutButton = findViewById(R.id.signOutButton);


        dbHelper = new UserDatabase(this);
        eventList = dbHelper.getAllEvents();

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));  // Use 2 columns for grid
        eventAdapter = new EventAdapter(eventList);
        recyclerView.setAdapter(eventAdapter);


        toggleEmptyView();

        addEventButton.setOnClickListener(view -> {
            try {
                Intent intent = new Intent(event_display.this, add_delete_event.class);
                startActivity(intent);
            } catch (Exception e) {
                Log.e("EventDisplay", "Error launching add_delete_event activity", e);
            }
        });



        signOutButton.setOnClickListener(view -> {
            Intent intent = new Intent(event_display.this, MainActivity.class);
            startActivity(intent);
            finish(); // Finish current activity
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_EVENT_REQUEST_CODE && resultCode == RESULT_OK) {
            // Refresh the event list and RecyclerView after returning from Add/Delete page
            eventList.clear();
            eventList.addAll(dbHelper.getAllEvents());
            eventAdapter.notifyDataSetChanged();
            toggleEmptyView();
        }
    }


    private void toggleEmptyView() {
        if (eventList.isEmpty()) {
            emptyTextView.setVisibility(TextView.VISIBLE);
            recyclerView.setVisibility(RecyclerView.GONE);
        } else {
            emptyTextView.setVisibility(TextView.GONE);
            recyclerView.setVisibility(RecyclerView.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}